/**
 * Upload every image in ./images-to-upload to Cloudinary (folder: promeo)
 * and print ready-to-paste `cloudinaryId` values for data/prompts.ts.
 *
 * Setup:
 *   1. cp .env.example .env.local and fill in your Cloudinary values
 *      (or export CLOUDINARY_CLOUD_NAME / API_KEY / API_SECRET).
 *   2. Drop image files into ./images-to-upload/
 *   3. npm run upload:cloudinary
 */
import { v2 as cloudinary } from 'cloudinary';
import { readdirSync, existsSync } from 'node:fs';
import { join, extname, basename } from 'node:path';

const cloudName =
  process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME || process.env.CLOUDINARY_CLOUD_NAME;
const apiKey = process.env.CLOUDINARY_API_KEY;
const apiSecret = process.env.CLOUDINARY_API_SECRET;

if (!cloudName || !apiKey || !apiSecret) {
  console.error(
    'Missing Cloudinary credentials. Set NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME (or CLOUDINARY_CLOUD_NAME), CLOUDINARY_API_KEY and CLOUDINARY_API_SECRET.',
  );
  process.exit(1);
}

cloudinary.config({ cloud_name: cloudName, api_key: apiKey, api_secret: apiSecret });

const dir = join(process.cwd(), 'images-to-upload');
if (!existsSync(dir)) {
  console.error('Create ./images-to-upload/ and put image files in it first.');
  process.exit(1);
}

const exts = new Set(['.jpg', '.jpeg', '.png', '.webp', '.avif', '.gif']);
const files = readdirSync(dir).filter((f) => exts.has(extname(f).toLowerCase()));

if (files.length === 0) {
  console.log('No images found in ./images-to-upload/');
  process.exit(0);
}

for (const file of files) {
  const res = await cloudinary.uploader.upload(join(dir, file), {
    folder: 'promeo',
    public_id: basename(file, extname(file)).toLowerCase().replace(/[^a-z0-9]+/g, '-'),
    resource_type: 'image',
  });
  console.log(`${file}  →  cloudinaryId: "${res.public_id}"   ${res.secure_url}`);
}
console.log('\nPaste each cloudinaryId into its entry in data/prompts.ts, then push — S3 redeploys automatically.');
