/** @type {import('next').NextConfig} */
const nextConfig = {
  // Static export — the whole site is plain HTML/CSS/JS so it can be
  // hosted from an AWS S3 bucket (same pattern as currency-visualizer).
  output: 'export',
  trailingSlash: true,
  images: {
    // S3 has no Next.js image optimizer, and images are served by
    // Cloudinary's CDN anyway, so pass image URLs through untouched.
    unoptimized: true,
    remotePatterns: [
      { protocol: 'https', hostname: 'res.cloudinary.com' },
      { protocol: 'https', hostname: 'picsum.photos' },
      { protocol: 'https', hostname: 'fastly.picsum.photos' },
    ],
  },
};

export default nextConfig;
