/**
 * Cloudinary helpers.
 *
 * Promeo hosts all gallery images on Cloudinary. A prompt entry can carry
 * either:
 *  - `cloudinaryId` — a Cloudinary public ID (preferred). The delivery URL
 *    is built from NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME, or
 *  - `image` — a full image URL (used for the demo seed data until Sai's
 *    own images are uploaded to his Cloudinary account).
 */

export const CLOUD_NAME =
  process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME || 'demo';

export function cldUrl(
  publicId: string,
  opts: { width?: number; height?: number; crop?: string } = {},
): string {
  const transforms = ['f_auto', 'q_auto'];
  if (opts.width) transforms.push(`w_${opts.width}`);
  if (opts.height) transforms.push(`h_${opts.height}`);
  if (opts.crop) transforms.push(`c_${opts.crop}`);
  return `https://res.cloudinary.com/${CLOUD_NAME}/image/upload/${transforms.join(',')}/${publicId}`;
}

export type PromptItem = {
  id: string;
  title: string;
  prompt: string;
  model: 'GPT Image' | 'Nano Banana' | 'Seedance' | 'Midjourney' | 'Veo' | 'Flux';
  category: string;
  tags: string[];
  author: string;
  authorHandle: string;
  /** Cloudinary public ID — set this once the image lives in your account. */
  cloudinaryId?: string;
  /** Full URL fallback (demo seed images). */
  image: string;
  width: number;
  height: number;
  likes: number;
  views: number;
};

export function imageSrc(p: PromptItem, width = 800): string {
  if (p.cloudinaryId) return cldUrl(p.cloudinaryId, { width });
  return p.image;
}
