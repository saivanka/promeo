# Promeo — The Best AI Prompts Gallery

**Promeo** is a free AI image & video prompts gallery in the style of MeiGen: a visual grid of images where **every image carries the exact prompt that created it**. Browse, search, filter by category or model, open any image, and copy its prompt in one click — no signup needed.

Built with **Next.js** (static export), images hosted on **Cloudinary**, deployed to an **AWS S3** static website bucket.

🔗 **Live:** http://promeo-saivanka.s3-website-us-east-1.amazonaws.com *(bucket: `promeo-saivanka`, us-east-1)*

## Features

- 🖼️ Pinterest-style masonry gallery of images + prompts
- 🔍 Live search across titles, prompt text and tags
- 🏷️ Category filters (Portraits, Poster & Editorial, Product & Ads, Illustration, 3D & CGI, Anime, Architecture, Fashion, Food, Branding & Logo, Cinematic)
- 🤖 Model filters — GPT Image, Nano Banana, Seedance, Midjourney, Veo, Flux
- 📄 A static detail page per prompt (`/prompt/<id>/`) with full prompt text, author credit, tags and related prompts
- ⧉ One-click **Copy Prompt** with copied-state feedback
- ☁️ **Cloudinary image hosting** — delivery URLs built from public IDs, plus an unsigned-upload widget on the Submit page
- 📱 Fully responsive, dark UI, SEO metadata + Open Graph per prompt

## Tech Stack

| Layer | Choice |
|---|---|
| Framework | Next.js 15 (App Router) + React 19 + TypeScript |
| Styling | Tailwind CSS 3 |
| Images | Cloudinary CDN (`res.cloudinary.com`) |
| Hosting | AWS S3 static website (static export — no server) |
| CI/CD | GitHub Actions → `aws s3 sync` |

## Run Locally

```bash
npm install
cp .env.example .env.local   # fill in your Cloudinary values
npm run dev                  # http://localhost:3000
npm run build                # static export lands in ./out
```

## Adding a Prompt (the whole content model)

Promeo content is only **an image + its prompt**. All entries live in [`data/prompts.ts`](data/prompts.ts):

1. Upload the image to Cloudinary:
   - Easiest: open the site's **Submit** page (uses the Cloudinary upload widget), or
   - Batch: put files in `images-to-upload/` and run `npm run upload:cloudinary` — it prints each `cloudinaryId`.
2. Add one entry with `cloudinaryId`, `title`, `prompt`, `model`, `category`, `tags`, and author credit.
3. Push to `main` / run the deploy workflow — S3 updates automatically.

## Cloudinary Setup (one time)

1. Create a free account at cloudinary.com.
2. Note your **Cloud name** (Dashboard).
3. Settings → Upload → **Add upload preset** → Signing Mode: **Unsigned** → name it e.g. `promeo_unsigned`.
4. Set repo Variables (GitHub → Settings → Secrets and variables → Actions → Variables):
   `NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME`, `NEXT_PUBLIC_CLOUDINARY_UPLOAD_PRESET`.

## S3 Deployment

One-time bucket setup (AWS console): create bucket `promeo-saivanka` (us-east-1) → Properties → Static website hosting: **Enable**, index document `index.html`, error document `404.html` → Permissions → turn **off** "Block all public access" → add a public-read bucket policy for `/*`.

GitHub repo **Secrets**: `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`.
GitHub repo **Variables**: `S3_BUCKET=promeo-saivanka`, `AWS_REGION=us-east-1`, plus the two Cloudinary variables above.

Then run **Actions → Deploy Promeo to S3 → Run workflow** (manual, same pattern as currency-visualizer). Or deploy from your machine:

```bash
npm run build
aws s3 sync out/ s3://promeo-saivanka/ --delete
```

## Project Layout

```
app/            Pages: home gallery, prompt detail, submit
components/     Header, Footer, Gallery (search/filter), PromptCard, CopyButton, UploadWidget
data/prompts.ts The entire content — images + prompts
lib/cloudinary.ts  Cloudinary URL builder + types
scripts/        Batch Cloudinary uploader
.github/workflows/deploy-s3.yml  Build + S3 deploy
```

## Notes

- The 12 seed entries use placeholder photos so the layout can be reviewed immediately. Replace each with your own Cloudinary image + prompt — that's the intended content workflow.
- Static export means no database and no server costs: S3 + Cloudinary free tiers cover this site.
