import Link from 'next/link';
import Image from 'next/image';
import { notFound } from 'next/navigation';
import type { Metadata } from 'next';
import { PROMPTS } from '@/data/prompts';
import { imageSrc } from '@/lib/cloudinary';
import CopyButton from '@/components/CopyButton';
import PromptCard from '@/components/PromptCard';

export function generateStaticParams() {
  return PROMPTS.map((p) => ({ id: p.id }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}): Promise<Metadata> {
  const { id } = await params;
  const p = PROMPTS.find((x) => x.id === id);
  if (!p) return { title: 'Prompt not found — Promeo' };
  return {
    title: `${p.title} — ${p.model} Prompt | Promeo`,
    description: p.prompt.slice(0, 155),
    openGraph: {
      title: p.title,
      description: p.prompt.slice(0, 155),
      images: [imageSrc(p, 1200)],
    },
  };
}

export default async function PromptDetail({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const p = PROMPTS.find((x) => x.id === id);
  if (!p) notFound();

  const related = PROMPTS.filter(
    (x) => x.id !== p.id && (x.category === p.category || x.model === p.model),
  ).slice(0, 4);

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <Link href="/#gallery" className="text-sm text-white/55 hover:text-white">
        ← Back to gallery
      </Link>

      <div className="mt-6 grid gap-10 lg:grid-cols-2">
        <div className="overflow-hidden rounded-3xl border border-line bg-card">
          <Image
            src={imageSrc(p, 1000)}
            alt={p.title}
            width={p.width}
            height={p.height}
            className="w-full object-cover"
            priority
          />
        </div>

        <div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="rounded-full bg-brand-500/15 px-3 py-1 text-xs font-bold text-brand-400">
              {p.model}
            </span>
            <span className="rounded-full border border-line px-3 py-1 text-xs font-medium text-white/65">
              {p.category}
            </span>
            <span className="ml-auto text-sm text-white/45">
              ♥ {p.likes.toLocaleString()} · 👁 {p.views.toLocaleString()} views
            </span>
          </div>

          <h1 className="mt-4 font-display text-3xl font-bold leading-tight sm:text-4xl">
            {p.title}
          </h1>

          <div className="mt-4 flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-brand-500 to-accent font-display font-bold text-white">
              {p.author.charAt(0)}
            </span>
            <div>
              <p className="text-sm font-semibold">{p.author}</p>
              <p className="text-xs text-white/45">{p.authorHandle}</p>
            </div>
          </div>

          <h2 className="mt-8 font-display text-sm font-semibold uppercase tracking-wider text-white/70">
            The Prompt
          </h2>
          <div className="mt-3 rounded-2xl border border-line bg-panel p-5">
            <p className="whitespace-pre-wrap text-[15px] leading-relaxed text-white/85">
              {p.prompt}
            </p>
          </div>
          <div className="mt-4 flex flex-wrap gap-3">
            <CopyButton text={p.prompt} />
            <a
              href="#related"
              className="rounded-full border border-line px-4 py-2 text-sm font-medium text-white/75 transition hover:border-brand-500 hover:text-white"
            >
              More like this
            </a>
          </div>

          <div className="mt-8">
            <h3 className="font-display text-sm font-semibold uppercase tracking-wider text-white/70">
              Tags
            </h3>
            <div className="mt-3 flex flex-wrap gap-2">
              {p.tags.map((t) => (
                <span
                  key={t}
                  className="rounded-full bg-white/5 px-3 py-1 text-xs text-white/60"
                >
                  #{t}
                </span>
              ))}
            </div>
          </div>

          <div className="mt-8 rounded-2xl border border-brand-500/30 bg-brand-500/10 p-5 text-sm leading-relaxed text-white/70">
            <strong className="text-white">How to use it:</strong> copy the prompt,
            paste it into {p.model} (or your favorite image model), swap the
            bracketed parts for your own subject, and generate. That&apos;s it —
            no signup needed on Promeo, ever.
          </div>
        </div>
      </div>

      {related.length > 0 && (
        <section id="related" className="mt-16 scroll-mt-24">
          <h2 className="font-display text-2xl font-bold">Related Prompts</h2>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {related.map((r) => (
              <PromptCard key={r.id} p={r} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
