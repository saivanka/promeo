import Link from 'next/link';
import Gallery from '@/components/Gallery';
import { PROMPTS } from '@/data/prompts';

const totalViews = PROMPTS.reduce((s, p) => s + p.views, 0);

export default function HomePage() {
  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute -top-32 left-1/2 h-96 w-[42rem] -translate-x-1/2 rounded-full bg-brand-600/25 blur-3xl" />
        <div className="relative mx-auto max-w-7xl px-4 pb-10 pt-14 text-center sm:px-6">
          <p className="inline-block rounded-full border border-brand-500/40 bg-brand-500/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-widest text-brand-400">
            Free AI Prompts Gallery — No signup to browse &amp; copy
          </p>
          <h1 className="mx-auto mt-6 max-w-3xl font-display text-4xl font-bold leading-[1.08] tracking-tight sm:text-6xl">
            The Best AI Image &amp; Video{' '}
            <span className="bg-gradient-to-r from-brand-400 to-accent bg-clip-text text-transparent">
              Prompts
            </span>{' '}
            on the Internet
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-white/60 sm:text-lg">
            Every picture on Promeo comes with the exact prompt that created it.
            Find one you love, copy the prompt, and make it yours with GPT Image,
            Nano Banana, Seedance, Midjourney, Veo or Flux.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <a
              href="#gallery"
              className="rounded-full bg-gradient-to-r from-brand-600 to-accent px-7 py-3 font-semibold text-white shadow-glow transition hover:opacity-90"
            >
              Explore Prompts ↓
            </a>
            <Link
              href="/submit/"
              className="rounded-full border border-line px-7 py-3 font-semibold text-white/85 transition hover:border-brand-500 hover:text-white"
            >
              Share Your Prompt
            </Link>
          </div>
          <div className="mt-10 flex items-center justify-center gap-8 text-center">
            <div>
              <p className="font-display text-2xl font-bold">{PROMPTS.length}+</p>
              <p className="text-xs uppercase tracking-wider text-white/45">Curated prompts</p>
            </div>
            <div>
              <p className="font-display text-2xl font-bold">6</p>
              <p className="text-xs uppercase tracking-wider text-white/45">AI models</p>
            </div>
            <div>
              <p className="font-display text-2xl font-bold">
                {(totalViews / 1000).toFixed(0)}k
              </p>
              <p className="text-xs uppercase tracking-wider text-white/45">Prompt views</p>
            </div>
            <div>
              <p className="font-display text-2xl font-bold">$0</p>
              <p className="text-xs uppercase tracking-wider text-white/45">Forever free</p>
            </div>
          </div>
        </div>
      </section>

      <Gallery />
    </>
  );
}
