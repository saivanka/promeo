import type { Metadata } from 'next';
import './globals.css';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export const metadata: Metadata = {
  title: 'Promeo — The Best AI Prompts Gallery | Free GPT Image, Nano Banana & Seedance Prompts',
  description:
    'Promeo is the best free gallery of AI image and video prompts. Browse beautiful images, copy the exact prompt behind each one, and generate with GPT Image, Nano Banana, Seedance, Midjourney, Veo and Flux — no signup needed to browse and copy.',
  keywords: [
    'AI prompts',
    'image prompts',
    'GPT Image prompts',
    'Nano Banana prompts',
    'Seedance prompts',
    'Midjourney prompts',
    'prompt gallery',
    'Promeo',
  ],
  openGraph: {
    title: 'Promeo — The Best AI Prompts Gallery',
    description:
      'Browse, copy and create with the best AI image & video prompts. Free, no signup to browse.',
    type: 'website',
    siteName: 'Promeo',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen font-sans antialiased">
        <Header />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  );
}
