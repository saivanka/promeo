'use client';

import { useState } from 'react';
import UploadWidget from '@/components/UploadWidget';
import { CATEGORIES, MODELS } from '@/data/prompts';

export default function SubmitPage() {
  const [title, setTitle] = useState('');
  const [prompt, setPrompt] = useState('');
  const [model, setModel] = useState<string>('GPT Image');
  const [category, setCategory] = useState<string>('Portraits');
  const [author, setAuthor] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [publicId, setPublicId] = useState('');
  const [sent, setSent] = useState(false);

  const entry = {
    id: title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, ''),
    title,
    prompt,
    model,
    category,
    tags: [],
    author: author || 'Anonymous',
    authorHandle: '',
    cloudinaryId: publicId || undefined,
    image: imageUrl,
  };

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const existing = JSON.parse(
      localStorage.getItem('promeo-submissions') || '[]',
    ) as unknown[];
    existing.push({ ...entry, submittedAt: new Date().toISOString() });
    localStorage.setItem('promeo-submissions', JSON.stringify(existing));
    setSent(true);
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <h1 className="font-display text-4xl font-bold">Share a Prompt</h1>
      <p className="mt-3 leading-relaxed text-white/60">
        Promeo grows one image + one prompt at a time. Upload your image to
        Cloudinary, paste the exact prompt that created it, and submit — new
        entries are reviewed and added to the gallery data file.
      </p>

      {sent ? (
        <div className="mt-8 rounded-2xl border border-emerald-500/40 bg-emerald-500/10 p-6">
          <p className="font-display text-lg font-semibold text-emerald-300">
            ✓ Submission saved!
          </p>
          <p className="mt-2 text-sm leading-relaxed text-white/65">
            To publish it on the live gallery, add this entry to{' '}
            <code className="rounded bg-white/10 px-1.5 py-0.5">data/prompts.ts</code>{' '}
            in the GitHub repo and the S3 deploy workflow ships it automatically:
          </p>
          <pre className="mt-4 max-h-64 overflow-auto rounded-xl bg-black/40 p-4 text-xs leading-relaxed text-white/75">
            {JSON.stringify(entry, null, 2)}
          </pre>
        </div>
      ) : (
        <form onSubmit={submit} className="mt-8 space-y-5">
          <UploadWidget
            onUploaded={(url, pid) => {
              setImageUrl(url);
              setPublicId(pid);
            }}
          />
          {imageUrl && (
            <p className="rounded-xl bg-emerald-500/10 px-4 py-3 text-sm text-emerald-300">
              ✓ Image hosted on Cloudinary: {publicId}
            </p>
          )}

          <label className="block">
            <span className="text-sm font-medium text-white/75">Image URL (if not uploading)</span>
            <input
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              placeholder="https://res.cloudinary.com/…"
              className="mt-1.5 w-full rounded-xl border border-line bg-panel px-4 py-3 text-sm focus:border-brand-500 focus:outline-none"
            />
          </label>

          <label className="block">
            <span className="text-sm font-medium text-white/75">Title</span>
            <input
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Neon Rain Portrait — Tokyo Alley"
              className="mt-1.5 w-full rounded-xl border border-line bg-panel px-4 py-3 text-sm focus:border-brand-500 focus:outline-none"
            />
          </label>

          <label className="block">
            <span className="text-sm font-medium text-white/75">The exact prompt</span>
            <textarea
              required
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              rows={7}
              placeholder="Ultra-photorealistic portrait of…"
              className="mt-1.5 w-full rounded-xl border border-line bg-panel px-4 py-3 text-sm leading-relaxed focus:border-brand-500 focus:outline-none"
            />
          </label>

          <div className="grid gap-5 sm:grid-cols-2">
            <label className="block">
              <span className="text-sm font-medium text-white/75">Model</span>
              <select
                value={model}
                onChange={(e) => setModel(e.target.value)}
                className="mt-1.5 w-full rounded-xl border border-line bg-panel px-4 py-3 text-sm focus:border-brand-500 focus:outline-none"
              >
                {MODELS.filter((m) => m !== 'All Models').map((m) => (
                  <option key={m} value={m}>
                    {m}
                  </option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className="text-sm font-medium text-white/75">Category</span>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="mt-1.5 w-full rounded-xl border border-line bg-panel px-4 py-3 text-sm focus:border-brand-500 focus:outline-none"
              >
                {CATEGORIES.filter((c) => c !== 'All').map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </label>
          </div>

          <label className="block">
            <span className="text-sm font-medium text-white/75">Your name (credit)</span>
            <input
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
              placeholder="Sai Vanka"
              className="mt-1.5 w-full rounded-xl border border-line bg-panel px-4 py-3 text-sm focus:border-brand-500 focus:outline-none"
            />
          </label>

          <button
            type="submit"
            className="w-full rounded-full bg-gradient-to-r from-brand-600 to-accent py-3.5 font-semibold text-white shadow-glow transition hover:opacity-90"
          >
            Submit Prompt
          </button>
        </form>
      )}
    </div>
  );
}
