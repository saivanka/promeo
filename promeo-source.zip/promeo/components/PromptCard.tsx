import Link from 'next/link';
import Image from 'next/image';
import { imageSrc, type PromptItem } from '@/lib/cloudinary';

const MODEL_STYLES: Record<PromptItem['model'], string> = {
  'GPT Image': 'bg-sky-500/90',
  'Nano Banana': 'bg-amber-500/90',
  Seedance: 'bg-fuchsia-500/90',
  Midjourney: 'bg-indigo-500/90',
  Veo: 'bg-emerald-500/90',
  Flux: 'bg-rose-500/90',
};

export default function PromptCard({ p }: { p: PromptItem }) {
  return (
    <article className="group relative overflow-hidden rounded-2xl border border-line bg-card transition hover:border-brand-500/60">
      <Link href={`/prompt/${p.id}/`} aria-label={p.title}>
        <div className="relative">
          <Image
            src={imageSrc(p, 700)}
            alt={p.title}
            width={p.width}
            height={p.height}
            className="w-full object-cover transition duration-500 group-hover:scale-[1.03]"
            loading="lazy"
          />
          <span
            className={`absolute left-3 top-3 rounded-full px-2.5 py-1 text-[11px] font-bold text-white ${MODEL_STYLES[p.model]}`}
          >
            {p.model}
          </span>
          <div className="pointer-events-none absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-black/75 to-transparent opacity-0 transition group-hover:opacity-100" />
          <span className="absolute bottom-3 right-3 rounded-full bg-white px-3 py-1.5 text-xs font-semibold text-ink opacity-0 shadow transition group-hover:opacity-100">
            View Prompt →
          </span>
        </div>
      </Link>

      <div className="p-4">
        <Link href={`/prompt/${p.id}/`}>
          <h3 className="line-clamp-1 font-display text-[15px] font-semibold leading-snug hover:text-brand-400">
            {p.title}
          </h3>
        </Link>
        <p className="mt-1.5 line-clamp-2 text-[13px] leading-relaxed text-white/50">
          {p.prompt}
        </p>
        <div className="mt-3 flex items-center gap-2 text-xs text-white/50">
          <span className="grid h-6 w-6 place-items-center rounded-full bg-gradient-to-br from-brand-500 to-accent text-[10px] font-bold text-white">
            {p.author.charAt(0)}
          </span>
          <span className="font-medium text-white/70">{p.authorHandle}</span>
          <span className="ml-auto">♥ {p.likes.toLocaleString()}</span>
          <span>👁 {(p.views / 1000).toFixed(1)}k</span>
        </div>
      </div>
    </article>
  );
}
