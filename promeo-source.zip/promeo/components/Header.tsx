import Link from 'next/link';

export default function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-line bg-ink/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-6 px-4 sm:px-6">
        <Link href="/" className="flex items-center gap-2.5">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-brand-500 to-accent font-display text-lg font-bold text-white shadow-glow">
            P
          </span>
          <span className="font-display text-xl font-bold tracking-tight">
            Promeo
            <span className="ml-2 hidden rounded-full bg-brand-500/15 px-2 py-0.5 align-middle text-[11px] font-semibold text-brand-400 sm:inline">
              THE BEST
            </span>
          </span>
        </Link>

        <nav className="hidden items-center gap-6 text-sm font-medium text-white/70 md:flex">
          <Link href="/" className="transition hover:text-white">
            Explore
          </Link>
          <Link href="/#gallery" className="transition hover:text-white">
            Categories
          </Link>
          <Link href="/#gallery" className="transition hover:text-white">
            Models
          </Link>
          <Link href="/submit/" className="transition hover:text-white">
            Submit a Prompt
          </Link>
        </nav>

        <div className="ml-auto flex items-center gap-3">
          <Link
            href="/#gallery"
            className="hidden rounded-full border border-line px-4 py-2 text-sm font-medium text-white/80 transition hover:border-brand-500 hover:text-white sm:block"
          >
            Browse Prompts
          </Link>
          <Link
            href="/submit/"
            className="rounded-full bg-gradient-to-r from-brand-600 to-accent px-4 py-2 text-sm font-semibold text-white shadow-glow transition hover:opacity-90"
          >
            + Add Prompt
          </Link>
        </div>
      </div>
    </header>
  );
}
