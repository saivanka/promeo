'use client';

import { useMemo, useState } from 'react';
import PromptCard from './PromptCard';
import { CATEGORIES, MODELS, PROMPTS } from '@/data/prompts';

export default function Gallery() {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<string>('All');
  const [model, setModel] = useState<string>('All Models');
  const [sort, setSort] = useState<'popular' | 'liked' | 'az'>('popular');

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    let list = PROMPTS.filter((p) => {
      if (category !== 'All' && p.category !== category) return false;
      if (model !== 'All Models' && p.model !== model) return false;
      if (!q) return true;
      return (
        p.title.toLowerCase().includes(q) ||
        p.prompt.toLowerCase().includes(q) ||
        p.tags.some((t) => t.toLowerCase().includes(q))
      );
    });
    if (sort === 'popular') list = [...list].sort((a, b) => b.views - a.views);
    if (sort === 'liked') list = [...list].sort((a, b) => b.likes - a.likes);
    if (sort === 'az') list = [...list].sort((a, b) => a.title.localeCompare(b.title));
    return list;
  }, [query, category, model, sort]);

  return (
    <section id="gallery" className="mx-auto max-w-7xl scroll-mt-20 px-4 pb-20 sm:px-6">
      {/* Search + sort */}
      <div className="flex flex-col gap-3 sm:flex-row">
        <label className="relative flex-1">
          <span className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-white/40">
            🔍
          </span>
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search prompts — try “portrait”, “poster”, “ramen”…"
            className="w-full rounded-full border border-line bg-panel py-3 pl-11 pr-4 text-sm text-white placeholder:text-white/35 focus:border-brand-500 focus:outline-none"
          />
        </label>
        <select
          value={model}
          onChange={(e) => setModel(e.target.value)}
          className="rounded-full border border-line bg-panel px-4 py-3 text-sm text-white/80 focus:border-brand-500 focus:outline-none"
        >
          {MODELS.map((m) => (
            <option key={m} value={m}>
              {m}
            </option>
          ))}
        </select>
        <select
          value={sort}
          onChange={(e) => setSort(e.target.value as typeof sort)}
          className="rounded-full border border-line bg-panel px-4 py-3 text-sm text-white/80 focus:border-brand-500 focus:outline-none"
        >
          <option value="popular">Most viewed</option>
          <option value="liked">Most liked</option>
          <option value="az">A – Z</option>
        </select>
      </div>

      {/* Category pills */}
      <div className="mt-5 flex flex-wrap gap-2">
        {CATEGORIES.map((c) => (
          <button
            key={c}
            onClick={() => setCategory(c)}
            className={`rounded-full px-4 py-2 text-sm font-medium transition ${
              category === c
                ? 'bg-gradient-to-r from-brand-600 to-accent text-white shadow-glow'
                : 'border border-line bg-panel text-white/65 hover:border-brand-500 hover:text-white'
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      <p className="mt-6 text-sm text-white/45">
        Showing <span className="font-semibold text-white">{results.length}</span> of{' '}
        {PROMPTS.length} prompts — every one free to copy.
      </p>

      {results.length === 0 ? (
        <div className="mt-10 rounded-2xl border border-dashed border-line bg-panel p-12 text-center">
          <p className="font-display text-lg font-semibold">No prompts match that search</p>
          <p className="mt-2 text-sm text-white/50">
            Try a different keyword, or clear the category and model filters.
          </p>
          <button
            onClick={() => {
              setQuery('');
              setCategory('All');
              setModel('All Models');
            }}
            className="mt-5 rounded-full bg-gradient-to-r from-brand-600 to-accent px-5 py-2.5 text-sm font-semibold text-white"
          >
            Clear filters
          </button>
        </div>
      ) : (
        <div className="masonry mt-6">
          {results.map((p) => (
            <PromptCard key={p.id} p={p} />
          ))}
        </div>
      )}
    </section>
  );
}
