import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="border-t border-line bg-panel">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:px-6 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-brand-500 to-accent font-display text-lg font-bold text-white">
              P
            </span>
            <span className="font-display text-xl font-bold">Promeo</span>
          </div>
          <p className="mt-3 text-sm leading-relaxed text-white/55">
            The best free AI prompts gallery. Every image ships with the exact
            prompt that created it — browse, copy, and create something better.
          </p>
        </div>

        <div>
          <h3 className="font-display text-sm font-semibold uppercase tracking-wider text-white/85">
            Explore
          </h3>
          <ul className="mt-3 space-y-2 text-sm text-white/55">
            <li><Link href="/#gallery" className="hover:text-white">All Prompts</Link></li>
            <li><Link href="/#gallery" className="hover:text-white">GPT Image Prompts</Link></li>
            <li><Link href="/#gallery" className="hover:text-white">Nano Banana Prompts</Link></li>
            <li><Link href="/#gallery" className="hover:text-white">Seedance Video Prompts</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="font-display text-sm font-semibold uppercase tracking-wider text-white/85">
            Categories
          </h3>
          <ul className="mt-3 space-y-2 text-sm text-white/55">
            <li><Link href="/#gallery" className="hover:text-white">Portraits</Link></li>
            <li><Link href="/#gallery" className="hover:text-white">Poster &amp; Editorial</Link></li>
            <li><Link href="/#gallery" className="hover:text-white">Product &amp; Ads</Link></li>
            <li><Link href="/#gallery" className="hover:text-white">Illustration &amp; 3D</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="font-display text-sm font-semibold uppercase tracking-wider text-white/85">
            Promeo
          </h3>
          <ul className="mt-3 space-y-2 text-sm text-white/55">
            <li><Link href="/submit/" className="hover:text-white">Submit a Prompt</Link></li>
            <li>
              <a
                href="https://github.com/saivanka/promeo"
                target="_blank"
                rel="noreferrer"
                className="hover:text-white"
              >
                GitHub
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-line py-5 text-center text-xs text-white/40">
        © {new Date().getFullYear()} Promeo — The Best AI Prompts Gallery. Prompts are shared by their
        creators for learning and inspiration.
      </div>
    </footer>
  );
}
