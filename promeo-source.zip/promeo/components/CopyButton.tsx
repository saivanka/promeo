'use client';

import { useState } from 'react';

export default function CopyButton({
  text,
  label = 'Copy Prompt',
  className = '',
}: {
  text: string;
  label?: string;
  className?: string;
}) {
  const [copied, setCopied] = useState(false);

  async function copy() {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <button
      onClick={copy}
      className={`inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold transition ${
        copied
          ? 'bg-emerald-500 text-white'
          : 'bg-gradient-to-r from-brand-600 to-accent text-white hover:opacity-90'
      } ${className}`}
    >
      {copied ? '✓ Copied!' : `⧉ ${label}`}
    </button>
  );
}
