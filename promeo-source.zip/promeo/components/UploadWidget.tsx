'use client';

import { useEffect, useState } from 'react';

declare global {
  interface Window {
    cloudinary?: {
      createUploadWidget: (
        options: Record<string, unknown>,
        callback: (error: unknown, result: { event: string; info?: { secure_url: string; public_id: string } }) => void,
      ) => { open: () => void };
    };
  }
}

/**
 * Cloudinary unsigned-upload widget.
 * Needs NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME and
 * NEXT_PUBLIC_CLOUDINARY_UPLOAD_PRESET (an *unsigned* preset created in the
 * Cloudinary console: Settings → Upload → Upload presets).
 */
export default function UploadWidget({
  onUploaded,
}: {
  onUploaded: (url: string, publicId: string) => void;
}) {
  const [ready, setReady] = useState(false);
  const cloudName = process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME;
  const preset = process.env.NEXT_PUBLIC_CLOUDINARY_UPLOAD_PRESET;

  useEffect(() => {
    if (!cloudName || !preset) return;
    const script = document.createElement('script');
    script.src = 'https://widget.cloudinary.com/v2.0/global/all.js';
    script.onload = () => setReady(true);
    document.body.appendChild(script);
  }, [cloudName, preset]);

  if (!cloudName || !preset) {
    return (
      <div className="rounded-2xl border border-dashed border-line bg-panel p-5 text-sm leading-relaxed text-white/60">
        <p className="font-semibold text-white">Image upload is in “owner setup” mode.</p>
        <p className="mt-2">
          To switch on direct uploads, create a free Cloudinary account, add an
          unsigned upload preset, and set{' '}
          <code className="rounded bg-white/10 px-1.5 py-0.5 text-[13px]">
            NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME
          </code>{' '}
          and{' '}
          <code className="rounded bg-white/10 px-1.5 py-0.5 text-[13px]">
            NEXT_PUBLIC_CLOUDINARY_UPLOAD_PRESET
          </code>{' '}
          (see <code className="rounded bg-white/10 px-1.5 py-0.5 text-[13px]">.env.example</code>),
          then rebuild. Until then, submissions arrive as text and the image is
          attached by the site owner.
        </p>
      </div>
    );
  }

  function openWidget() {
    if (!window.cloudinary) return;
    const widget = window.cloudinary.createUploadWidget(
      {
        cloudName,
        uploadPreset: preset,
        folder: 'promeo',
        sources: ['local', 'url'],
        multiple: false,
        resourceType: 'image',
      },
      (error, result) => {
        if (!error && result.event === 'success' && result.info) {
          onUploaded(result.info.secure_url, result.info.public_id);
        }
      },
    );
    widget.open();
  }

  return (
    <button
      type="button"
      onClick={openWidget}
      disabled={!ready}
      className="w-full rounded-xl border border-dashed border-brand-500/50 bg-brand-500/10 px-4 py-6 text-sm font-semibold text-brand-400 transition hover:bg-brand-500/20 disabled:opacity-50"
    >
      {ready ? '☁️ Upload image to Cloudinary' : 'Loading uploader…'}
    </button>
  );
}
